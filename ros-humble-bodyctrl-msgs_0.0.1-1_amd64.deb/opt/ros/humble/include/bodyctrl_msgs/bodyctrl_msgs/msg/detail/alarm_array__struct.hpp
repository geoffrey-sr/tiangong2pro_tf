// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from bodyctrl_msgs:msg/AlarmArray.idl
// generated code does not contain a copyright notice

#ifndef BODYCTRL_MSGS__MSG__DETAIL__ALARM_ARRAY__STRUCT_HPP_
#define BODYCTRL_MSGS__MSG__DETAIL__ALARM_ARRAY__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'alarm'
#include "bodyctrl_msgs/msg/detail/alarm__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__bodyctrl_msgs__msg__AlarmArray __attribute__((deprecated))
#else
# define DEPRECATED__bodyctrl_msgs__msg__AlarmArray __declspec(deprecated)
#endif

namespace bodyctrl_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AlarmArray_
{
  using Type = AlarmArray_<ContainerAllocator>;

  explicit AlarmArray_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    (void)_init;
  }

  explicit AlarmArray_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _alarm_type =
    std::vector<bodyctrl_msgs::msg::Alarm_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<bodyctrl_msgs::msg::Alarm_<ContainerAllocator>>>;
  _alarm_type alarm;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__alarm(
    const std::vector<bodyctrl_msgs::msg::Alarm_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<bodyctrl_msgs::msg::Alarm_<ContainerAllocator>>> & _arg)
  {
    this->alarm = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator> *;
  using ConstRawPtr =
    const bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__bodyctrl_msgs__msg__AlarmArray
    std::shared_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__bodyctrl_msgs__msg__AlarmArray
    std::shared_ptr<bodyctrl_msgs::msg::AlarmArray_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AlarmArray_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->alarm != other.alarm) {
      return false;
    }
    return true;
  }
  bool operator!=(const AlarmArray_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AlarmArray_

// alias to use template instance with default allocator
using AlarmArray =
  bodyctrl_msgs::msg::AlarmArray_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace bodyctrl_msgs

#endif  // BODYCTRL_MSGS__MSG__DETAIL__ALARM_ARRAY__STRUCT_HPP_
