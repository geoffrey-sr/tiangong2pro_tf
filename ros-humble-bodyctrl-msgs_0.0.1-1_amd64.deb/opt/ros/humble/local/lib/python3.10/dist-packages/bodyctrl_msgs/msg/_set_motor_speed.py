# generated from rosidl_generator_py/resource/_idl.py.em
# with input from bodyctrl_msgs:msg/SetMotorSpeed.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SetMotorSpeed(type):
    """Metaclass of message 'SetMotorSpeed'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('bodyctrl_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'bodyctrl_msgs.msg.SetMotorSpeed')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__set_motor_speed
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__set_motor_speed
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__set_motor_speed
            cls._TYPE_SUPPORT = module.type_support_msg__msg__set_motor_speed
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__set_motor_speed

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SetMotorSpeed(metaclass=Metaclass_SetMotorSpeed):
    """Message class 'SetMotorSpeed'."""

    __slots__ = [
        '_name',
        '_spd',
        '_cur',
    ]

    _fields_and_field_types = {
        'name': 'uint16',
        'spd': 'float',
        'cur': 'float',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint16'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.name = kwargs.get('name', int())
        self.spd = kwargs.get('spd', float())
        self.cur = kwargs.get('cur', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.name != other.name:
            return False
        if self.spd != other.spd:
            return False
        if self.cur != other.cur:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def name(self):
        """Message field 'name'."""
        return self._name

    @name.setter
    def name(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'name' field must be of type 'int'"
            assert value >= 0 and value < 65536, \
                "The 'name' field must be an unsigned integer in [0, 65535]"
        self._name = value

    @builtins.property
    def spd(self):
        """Message field 'spd'."""
        return self._spd

    @spd.setter
    def spd(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'spd' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'spd' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._spd = value

    @builtins.property
    def cur(self):
        """Message field 'cur'."""
        return self._cur

    @cur.setter
    def cur(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'cur' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'cur' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._cur = value
